// routes/konselingRoutes.js
const express = require('express');
const konselingController = require('../controllers/konselingController');
const konselingService = require('../services/konselingService');

const router = express.Router();

// Migrasi kolom tabel konseling saat modul dimuat
konselingService.initMigrations();

// Path spesifik dulu (sebelum /konseling/:nis atau /:id)
router.get('/konseling-all', konselingController.listAll);
router.get('/konseling-bk', konselingController.listByGuru);
router.get('/konseling/detail/:id', konselingController.getDetail);
router.post('/konseling/walkin', konselingController.walkin);
router.put('/konseling/:id/validasi', konselingController.validasi);
router.put('/konseling/:id/status', konselingController.updateStatus);
router.put('/konseling/:id/laporan', konselingController.simpanLaporan);
router.delete('/konseling/:id', konselingController.batalkan);
router.get('/konseling/:nis', konselingController.listByNis);
router.post('/konseling', konselingController.create);

module.exports = router;
