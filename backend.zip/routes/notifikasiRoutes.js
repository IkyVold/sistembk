// routes/notifikasiRoutes.js
const express = require('express');
const notifikasiController = require('../controllers/notifikasiController');
const notifikasiService = require('../services/notifikasiService');

const router = express.Router();

// Pastikan tabel notifikasi & push_subscriptions ada saat modul dimuat
notifikasiService.initTables();

// Web Push
router.get('/push/vapid-public-key', notifikasiController.getVapidPublicKey);
router.post('/push/subscribe', notifikasiController.subscribe);
router.post('/push/unsubscribe', notifikasiController.unsubscribe);

// Riwayat notifikasi (path spesifik dulu)
router.put('/notifikasi/:id/read', notifikasiController.markRead);
router.put('/notifikasi/:nis/read-all', notifikasiController.markAllRead);
router.get('/notifikasi/:nis', notifikasiController.list);

module.exports = router;
