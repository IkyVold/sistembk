// routes/riwayatKelasRoutes.js
const express = require('express');
const riwayatKelasController = require('../controllers/riwayatKelasController');
const riwayatKelasService = require('../services/riwayatKelasService');

const router = express.Router();

// Pastikan tabel ada saat modul dimuat (sama seperti init di server.js lama)
riwayatKelasService.initTable();

// Path lebih spesifik dulu
router.get('/riwayat-kelas/:nis/aktif', riwayatKelasController.getAktif);
router.get('/riwayat-kelas/:nis', riwayatKelasController.list);
router.post('/riwayat-kelas', riwayatKelasController.create);
router.delete('/riwayat-kelas/:id', riwayatKelasController.remove);

module.exports = router;
