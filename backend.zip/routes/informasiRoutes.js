// routes/informasiRoutes.js
const express = require('express');
const informasiController = require('../controllers/informasiController');
const informasiService = require('../services/informasiService');

const router = express.Router();

// Pastikan tabel ada saat modul dimuat
informasiService.initTable();

router.get('/informasi', informasiController.list);
router.post('/informasi', informasiController.create);
router.put('/informasi/:id', informasiController.update);
router.delete('/informasi/:id', informasiController.remove);

module.exports = router;
