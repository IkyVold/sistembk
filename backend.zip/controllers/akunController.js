// controllers/akunController.js
const akunService = require('../services/akunService');
const { asyncHandler } = require('../middleware/errorHandler');

const loginGuru = asyncHandler(async (req, res) => {
  const guru = await akunService.loginGuru(req.body);
  res.json({ success: true, guru });
});

const loginKepsek = asyncHandler(async (req, res) => {
  const kepsek = await akunService.loginKepsek(req.body);
  res.json({ success: true, kepsek });
});

const loginAdmin = asyncHandler(async (req, res) => {
  const admin = await akunService.loginAdmin(req.body);
  res.json({ success: true, admin });
});

const listGuruPublic = asyncHandler(async (req, res) => {
  const list = await akunService.listGuruPublic();
  res.json({ success: true, data: list });
});

const listGuruAdmin = asyncHandler(async (req, res) => {
  const list = await akunService.listGuruAdmin();
  res.json({ success: true, data: list });
});

const createGuru = asyncHandler(async (req, res) => {
  const result = await akunService.createGuru(req.body);
  res.status(201).json({ success: true, ...result });
});

const updateGuru = asyncHandler(async (req, res) => {
  const result = await akunService.updateGuru(req.params.id, req.body);
  res.json({ success: true, ...result });
});

const deleteGuru = asyncHandler(async (req, res) => {
  const result = await akunService.deleteGuru(req.params.id);
  res.json({ success: true, ...result });
});

const listKepsekAdmin = asyncHandler(async (req, res) => {
  const list = await akunService.listKepsekAdmin();
  res.json({ success: true, data: list });
});

const createKepsek = asyncHandler(async (req, res) => {
  const result = await akunService.createKepsek(req.body);
  res.status(201).json({ success: true, ...result });
});

const updateKepsek = asyncHandler(async (req, res) => {
  const result = await akunService.updateKepsek(req.params.id, req.body);
  res.json({ success: true, ...result });
});

const deleteKepsek = asyncHandler(async (req, res) => {
  const result = await akunService.deleteKepsek(req.params.id);
  res.json({ success: true, ...result });
});

const updateFotoGuru = asyncHandler(async (req, res) => {
  const result = await akunService.updateFotoGuru(req.params.username, req.file);
  res.json({ success: true, ...result });
});

const deleteFotoGuru = asyncHandler(async (req, res) => {
  const result = await akunService.deleteFotoGuru(req.params.username);
  res.json({ success: true, ...result });
});

module.exports = {
  loginGuru,
  loginKepsek,
  loginAdmin,
  listGuruPublic,
  listGuruAdmin,
  createGuru,
  updateGuru,
  deleteGuru,
  listKepsekAdmin,
  createKepsek,
  updateKepsek,
  deleteKepsek,
  updateFotoGuru,
  deleteFotoGuru,
};
