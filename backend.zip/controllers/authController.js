// controllers/authController.js
const authService = require('../services/authService');
const { asyncHandler } = require('../middleware/errorHandler');

const login = asyncHandler(async (req, res) => {
  const siswa = await authService.loginSiswa(req.body);
  res.json({ success: true, siswa });
});

module.exports = { login };
