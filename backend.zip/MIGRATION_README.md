# Backend Refactor — Stop Bullying (BK System)

Arsitektur berlapis (pure refactor, perilaku API tidak diubah):

```
routes/  →  controllers/  →  services/  →  models/  →  MySQL
                              ↑
                    utils/ + middleware/
socket/  →  services/chatService  →  models/chatModel
```

## Layer

| Layer | Tanggung jawab |
|-------|----------------|
| **routes/** | Definisi endpoint + middleware (multer, dsb.) |
| **controllers/** | req/res + `asyncHandler` |
| **services/** | Validasi & logika bisnis |
| **models/** | Pure query SQL (satu-satunya yang pakai `pool`) |
| **socket/** | Handler Socket.IO (event name & payload sama) |
| **utils/** | `HttpError`, `sanitize` |
| **middleware/** | `asyncHandler`, `errorHandler` |

## Models

- `siswaModel.js` — tabel `siswa`
- `riwayatKelasModel.js` — tabel `riwayat_kelas`
- `informasiModel.js` — tabel `informasi_bk`
- `konselingModel.js` — tabel `konseling`
- `notifikasiModel.js` — tabel `notifikasi` + `push_subscriptions`
- `chatModel.js` — tabel `chat_messages`

## Menjalankan

```bash
npm install
cp .env.example .env
npm start
```

Semua endpoint, event Socket.IO, Web Push, dan response shape
**tidak diubah** — hanya pemisahan folder/layer.
